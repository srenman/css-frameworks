import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  NavLink,
} from "react-router-dom";
import "./sass/style.scss";
import Navbar from "react-bootstrap/Navbar";
import Form from "react-bootstrap/Form";
import Nav from "react-bootstrap/Nav";
import FormControl from "react-bootstrap/FormControl";
import Button from "react-bootstrap/Button";
import Home from "./components/Home/Home";
import News from "./components/News/News";
import Footer from './components/GlobalComponents/Footer';


function App() {
  return (
    
    <Router>
    <div className="wrapper">
    
       <Navbar bg='light' expand='lg'>
        <Navbar.Brand href='#home' className="nav-logo">The YAY Company</Navbar.Brand>
        <Navbar.Toggle aria-controls='basic-navbar-nav' />
        <Navbar.Collapse id='basic-navbar-nav'>
          <Nav className='mr-auto'>
            <NavLink exact to='/' className="nav-link top-nav-links">
              Home
            </NavLink>
            <NavLink to='/news' className="nav-link top-nav-links">News</NavLink>
            <NavLink to='/contact' className="nav-link top-nav-links">Contact</NavLink>
          </Nav>
          <Form inline>
            <FormControl type='text' placeholder='Search' className='mr-sm-2' />
            <Button variant='outline-success'>Go</Button>
          </Form>
        </Navbar.Collapse>
      </Navbar>
      
        <Switch>
          <Route exact path='/'>
            <Home />
          </Route>
          <Route path='/news'>
            <News />
          </Route>
        </Switch>
      </div>
     <Footer />
      
    </Router>
   
  );
}

export default App;
