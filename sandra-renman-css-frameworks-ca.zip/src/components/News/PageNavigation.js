import React from "react";
import Pagination from "react-bootstrap/Pagination";

function PageNavigation() {
  return (
    <Pagination className="pagination">
      <Pagination.Item key={1} active={true}>
        1
      </Pagination.Item>
      <Pagination.Item key={2}>2</Pagination.Item>
      <Pagination.Item key={3}>3</Pagination.Item>
      <Pagination.Item key={4}>4</Pagination.Item>
    </Pagination>
  );
}

export default PageNavigation;
