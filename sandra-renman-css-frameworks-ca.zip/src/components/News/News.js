import React from "react";
import CardComponent from "./CardComponent";
import PageNavigation from "./PageNavigation";

export default function News() {
  return (
    <>
      <div className='news-wrapper'>
        <h1 className='header__heading news__heading'>News</h1>
        <PageNavigation />
        <section className='card-section'>
          <CardComponent imgPath='./img/news-1.png' />
          <CardComponent imgPath='./img/news-2.png' />
          <CardComponent imgPath='./img/news-3.png' />
          <CardComponent imgPath='./img/news-4.png' />
          <CardComponent imgPath='./img/news-5.png' />
          <CardComponent imgPath='./img/news-6.png' />
          <CardComponent imgPath='./img/news-7.png' />
          <CardComponent imgPath='./img/news-8.png' />
        </section>
      </div>
    </>
  );
}
