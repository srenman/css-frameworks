import React from "react";

function Footer() {
  return (
    <footer className='footer'>
      <div className='footer__item footer__item--soMe'>
      <i class="fab fa-vimeo-v"></i>
      <i class="fab fa-youtube"></i>
      </div>
      <div className='footer__item footer__item--email'>hello@yay.com</div>
      <div className='footer__item footer__item--copyright'>Copyright 2020</div>
    </footer>
  );
}

export default Footer;
