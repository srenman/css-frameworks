import React from "react";
import Tabs from "react-bootstrap/Tabs";
import Tab from "react-bootstrap/Tab";


function HomeTabs() {
  return (
  <div className="tabs-wrapper">
    <div className="d-none d-md-block">

      <Tabs defaultActiveKey='first' id='uncontrolled-tab-example'>
        <Tab eventKey='first' title='First' className="tab">
          <div className="tab__container">
            <div className="tab__container--img">
              <img
                className='tab__image'
                src='./img/tab-image.png'
                alt='TV'
              />
            </div>
            <div className="tab__container--text">
              <p className="tab__text">Morbi eget efficitur turpis. Vivamus pellentesque tortor massa, 
              venenatis pharetra leo laoreet a. Nullam non eleifend justo, a ullamcorper turpis. Cras vehicula 
              pharetra lectus non maximus. Sed condimentum mattis rhoncus. </p>
              <div className="tab__soMe">
                <p>SHARE</p>
                <i className="fab fa-facebook-f"></i>
                <i className="fab fa-twitter"></i>
              </div>
            </div>
        </div>
        </Tab>
        <Tab eventKey='second' title='Second' className="tab">
          <div className="tab__container">
            <div className="tab__container--img">
              <img
                  className='tab__image'
                  src='./img/tab-image.png'
                  alt='TV'
                />
              </div>
              <div className="tab__container--text">
                <p className="tab__text">Morbi eget efficitur turpis. Vivamus pellentesque tortor massa, 
                venenatis pharetra leo laoreet a. Nullam non eleifend justo, a ullamcorper turpis. Cras vehicula 
                pharetra lectus non maximus. Sed condimentum mattis rhoncus. </p>
                <div className="tab__soMe">
                  <p>SHARE</p>
                  <i className="fab fa-facebook-f"></i>
                  <i className="fab fa-twitter"></i>
                </div>
              </div>
            </div>      
        </Tab>
        
        <Tab eventKey='third   ' title='Third' className="tab">
          <div className="tab__container">
            <div className="tab__container--img">
              <img
                  className='tab__image'
                  src='./img/tab-image.png'
                  alt='TV'
                />
            </div>
            <div className="tab__container--text">
              <p className="tab__text">Morbi eget efficitur turpis. Vivamus pellentesque tortor massa, 
              venenatis pharetra leo laoreet a. Nullam non eleifend justo, a ullamcorper turpis. Cras vehicula 
              pharetra lectus non maximus. Sed condimentum mattis rhoncus. </p>
              <div className="tab__soMe">
                <p>SHARE</p>
                <i className="fab fa-facebook-f"></i>
                <i className="fab fa-twitter"></i>
              </div>
            </div>
          </div>
        </Tab>
      </Tabs>
    </div>
  </div>
  );
}

export default HomeTabs;
