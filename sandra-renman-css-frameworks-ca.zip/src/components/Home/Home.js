import React from "react";
import HomeCarousel from "./HomeCarousel";
import Header from "./Header";
import HomeTabs from "./HomeTabs";
import MobileTabs from "./MobileTabs";


export default function Home() {
  return (
    <>
      <HomeCarousel />
      <Header />
      <HomeTabs />
      <MobileTabs />
    </>
  );
}
