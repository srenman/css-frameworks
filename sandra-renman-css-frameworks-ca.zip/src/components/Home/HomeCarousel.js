import React from "react";
import Carousel from "react-bootstrap/Carousel";

function HomeCarousel() {
  return (
    <div>
      <Carousel className="carousel">
        <Carousel.Item>
          <img
            className='d-block w-100'
            src='./img/carousel-1.jpg'
            alt='First slide, YAY'
          />
       
        </Carousel.Item>
        <Carousel.Item>
          <img
            className='d-block w-100'
            src='./img/carousel-2.jpg'
            alt='Second slide, YAY'
          />
        </Carousel.Item>
        <Carousel.Item>
          <img
            className='d-block w-100'
            src='./img/carousel-3.jpg'
            alt='Third slide, YAY!'
          />
        </Carousel.Item>
      </Carousel>
    </div>
  );
}

export default HomeCarousel;
